<?php
function cariUserByUsername($conn, $username) {
    $query = "SELECT * FROM users WHERE username = ? LIMIT 1";
    $stmt  = $conn->prepare($query);

    $stmt->bind_param("s", $username);
    $stmt->execute();

    $hasil = $stmt->get_result();
    $user  = $hasil->fetch_assoc(); 

    $stmt->close();
    return $user;
}

function ambilSemuaUser($conn) {
    $query = "SELECT id, username, role, created_at FROM users ORDER BY id ASC";
    $hasil = $conn->query($query);
    return $hasil->fetch_all(MYSQLI_ASSOC);
}

function buatUser($conn, $username, $password, $role = 'user') {
    $passwordHash = password_hash($password, PASSWORD_BCRYPT);
    $query = "INSERT INTO users (username, password, role) VALUES (?, ?, ?)";
    $stmt  = $conn->prepare($query);

    $stmt->bind_param("sss", $username, $passwordHash, $role);
    $berhasil = $stmt->execute();

    $stmt->close();
    return $berhasil;
}
?>