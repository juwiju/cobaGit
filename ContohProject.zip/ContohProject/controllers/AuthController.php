<?php
session_start();
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../config/auth_helper.php';

require_once __DIR__ . '/../models/UserModel.php';

$aksi = $_GET['action'] ?? '';

if ($aksi === 'login') {
    prosesLogin();
} elseif ($aksi === 'logout') {
    prosesLogout();
} else {
    include __DIR__ . '/../views/auth/login.php';
}

function prosesLogin() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        include __DIR__ . '/../views/auth/login.php';
        return;
    }

    $username = trim($_POST['username'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($username) || empty($password)) {
        $pesanError = "Username dan password wajib diisi.";
        include __DIR__ . '/../views/auth/login.php';
        return;
    }

    global $conn;
    $dataUser = cariUserByUsername($conn, $username);

    if ($dataUser && $password === $dataUser['password']) {

        $_SESSION['user_id']  = $dataUser['id'];
        $_SESSION['username'] = $dataUser['username'];
        $_SESSION['role']     = $dataUser['role'];

        if ($dataUser['role'] === 'admin') {
            header("Location: /views/admin/dashboard.php");
        } else {
            header("Location: /views/user/dashboard.php");
        }
        exit;

    } else {
        $pesanError = "Username atau password salah.";
        include __DIR__ . '/../views/auth/login.php';
    }
}


function prosesLogout() {
    session_unset(); 
    session_destroy();
    header("Location: /views/auth/login.php");
    exit;
}
?>