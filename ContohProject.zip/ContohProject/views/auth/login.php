<?php
if (session_status() === PHP_SESSION_NONE) session_start();
if (isset($_SESSION['user_id'])) {
    header("Location: /index.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - RPL App</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body class="halaman-auth">
    <div class="kartu-login">
        <h2>Login</h2>
        <?php if (isset($pesanError)): ?>
            <div class="pesan-error">
                <?= htmlspecialchars($pesanError) ?>
            </div>
        <?php endif; ?>
        <form method="POST" action="/controllers/AuthController.php?action=login">
            <div class="form-group">
                <label for="username">Username</label>
                <input
                    type="text"
                    id="username"
                    name="username"
                    placeholder="Masukkan username"
                    value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                    required
                    autofocus>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input
                    type="password"
                    id="password"
                    name="password"
                    placeholder="Masukkan password"
                    required>
            </div>
            <button type="submit" class="tombol-login">Masuk</button>
        </form>
    </div>
</body>
</html>