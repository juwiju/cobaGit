<?php
session_start();
require_once __DIR__ . '/../../config/auth_helper.php';

requireLogin();
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard - RPL App</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

    <nav class="navbar">
        <span class="navbar-brand">RPL App</span>
        <div class="navbar-info">
            Halo, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>
            <span class="badge badge-user">User</span>
            <a href="/controllers/AuthController.php?action=logout" class="tombol-logout">Logout</a>
        </div>
    </nav>

    <main class="konten-utama">
        <h1>Dashboard</h1>
        <p>Selamat datang, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>!</p>

        <div class="kartu">
            <h3>Menu Tersedia</h3>
            <ul>
                <li>Lihat profil saya</li>
                <li>Lihat data</li>
            </ul>
        </div>

        <div class="kartu pesan-info">
            Anda login sebagai <strong>User biasa</strong>.
            Beberapa fitur hanya tersedia untuk Admin.
        </div>
    </main>

</body>
</html>