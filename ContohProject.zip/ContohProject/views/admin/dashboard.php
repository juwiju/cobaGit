<?php
session_start();
require_once __DIR__ . '/../../config/auth_helper.php';
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../models/UserModel.php';

requireRole('admin');

$daftarUser = ambilSemuaUser($conn);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Admin - RPL App</title>
    <link rel="stylesheet" href="/assets/css/style.css">
</head>
<body>

    <nav class="navbar">
        <span class="navbar-brand">RPL App</span>
        <div class="navbar-info">
            Halo, <strong><?= htmlspecialchars($_SESSION['username']) ?></strong>
            <span class="badge badge-admin">Admin</span>
            <a href="/controllers/AuthController.php?action=logout" class="tombol-logout">Logout</a>
        </div>
    </nav>

    <main class="konten-utama">
        <h1>Dashboard Admin</h1>
        <p>Selamat datang! Anda login sebagai <strong>Administrator</strong>.</p>

        <div class="kartu">
            <h3>Daftar Semua User</h3>
            <table class="tabel-data">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Username</th>
                        <th>Role</th>
                        <th>Dibuat</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($daftarUser as $user): ?>
                    <tr>
                        <td><?= $user['id'] ?></td>
                        <td><?= htmlspecialchars($user['username']) ?></td>
                        <td>
                            <span class="badge badge-<?= $user['role'] ?>">
                                <?= $user['role'] ?>
                            </span>
                        </td>
                        <td><?= $user['created_at'] ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>

</body>
</html>