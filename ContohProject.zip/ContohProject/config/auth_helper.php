<?php
function requireLogin() {
    if (!isset($_SESSION['user_id'])) {
        header("Location: /views/auth/login.php");
        exit;
    }
}

function requireRole($role) {
    requireLogin();
    if ($_SESSION['role'] !== $role) {
        http_response_code(403);
        echo "<h2>403 - Akses Ditolak</h2>";
        echo "<p>Anda tidak memiliki izin mengakses halaman ini.</p>";
        echo "<a href='/index.php'>Kembali</a>";
        exit;
    }
}

function sudahLogin() {
    return isset($_SESSION['user_id']);
}
?>