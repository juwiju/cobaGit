<?php
session_start();

$aksi = $_GET['action'] ?? 'home';

switch ($aksi) {
    case 'login':
    case 'logout':
        require_once 'controllers/AuthController.php';
        break;

    case 'dashboard':
        if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin') {
            header("Location: /views/admin/dashboard.php");
        } else {
            header("Location: /views/user/dashboard.php");
        }
        exit;

    default:
        if (isset($_SESSION['user_id'])) {
            header("Location: /index.php?action=dashboard");
        } else {
            require_once 'views/auth/login.php';
        }
        break;
}
?>